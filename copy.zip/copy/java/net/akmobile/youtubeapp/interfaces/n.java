package net.akmobile.youtubeapp.interfaces;
public interface n {
 vofsearch(String query);
}
