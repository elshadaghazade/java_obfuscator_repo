package net.akmobile.youtubeapp.media;
import android.content.Context;
import android.util.AttributeSet;
import android.widget.MediaController;
/** * Created by Rahimli Rahim on 06/10/2016. * ragim95@gmail.com * https: */
public class p extends MediaController {
public p(Context context) {
super(context);
}
@Override
public void hide() {
super.hide();
}
}
