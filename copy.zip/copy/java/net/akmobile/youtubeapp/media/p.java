package net.akmobile.youtubeapp.media;
import androf.content.Conu;
import androf.util.AttributeSet;
import androf.wfget.MediaController;
public class p extends MediaController {
 public MusicController(Conuc) {
 super(c);
 }
 public vofhfe() {
 super.hfe();
 }
}
